import json
import boto3
from botocore.exceptions import ClientError
import os

SYSTEM_PROMPT = """
You're a helpful assistant.
"""

def lambda_handler(event, context):
    body = json.loads(event["body"])

    client = boto3.client("bedrock-runtime", "us-east-1")
    model_id = "us.amazon.nova-2-lite-v1:0"
    inference_config = {
        "maxTokens": 200,
        "temperature": 0.8,
        "topP": 0.9
    }

    user_input = body["message"]

    prompt = f"""
        {SYSTEM_PROMPT}

        User: {user_input}
        Assistant:
    """
    messages = [{
            "role": "user",
            "content": [{"text": prompt}]
    }]
    try: 
        response = client.converse(
                modelId=model_id,
                messages=messages,
                inferenceConfig=inference_config
            )
        response_text = response["output"]["message"]["content"][0]["text"]
        return {
            "statusCode": 200,
            "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
            "body": json.dumps({
                "reply": response_text
            })
        }   

    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({
                "reply": str(e)
            })
        }
    
    print(generate_response(user_input))
    
    


    

    
