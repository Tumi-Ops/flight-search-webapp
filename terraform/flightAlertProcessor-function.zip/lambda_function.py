import os
import json
import boto3
import smtplib
import requests
from datetime import datetime
from flight_data import FlightData
from data_manager import DataManager
from flight_search import FlightSearch
from email.message import EmailMessage
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

table = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])
client = boto3.client('ssm')

params = None

def lambda_handler(event, context):
    search_flight()
    return {
        'statusCode': 200,
        'body': json.dumps('Flight processor complete!')
    }

def search_flight():
    try:
        response = table.query(
            IndexName="GSI1",
            KeyConditionExpression=Key('status').eq("ACTIVE")
        )
        alerts = response['Items']
    except ClientError as e:
        print(f"Error querying table: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Failed to retrieve items"})
        }
    for x in alerts:
        if x['status'] in ("TRIGGERED", "ACTIVE"):
            update_item(x["email"], x["created_at"], "TRIGGERED")
            data_manage = DataManager()
            data_manage.get_iata_codes(city=x['destination_city'], og_loc=x['origin_location'])

            fly_search = FlightSearch(data_manage)
            fly_search.get_flights(dep_date=x['from_date'],
                                   ret_date=x['to_date'], ad=x['adults'],
                                   child=x['children'], inf=x['infants'])

            fly_data = FlightData(data_manage, fly_search)
            
            structured_flights = fly_data.structured_flights
            
            for y in structured_flights:
                email_body = f"""Good news, a flight to {x['destination_city']} has been found. Here are the details:\n\n"
                  f"Price: R{y['price']}\n"
                  f"Airline: {y['airline']}\n"
                  f"Aircraft: {y['aircraft']}\n"
                  f"Seats Available: {y['seats_available']}\n"
                  f"Travel Class: {y['travel_class']}\n\n"
                  f"Visit this link to book the flight: https://www.google.com/search?q={y['airline']}\n."""

                if structured_flights and y['price'] <= x['max_price']:
                    response = send_email(x['email'], x['destination_city'], email_body)
                    print(response)
                    update_item(x['email'], x['created'], "EXPIRED")
                else:
                    print(f"No flights found to {x['destination_city']} for user {x['email']}")
    return response

def get_email_secrets():
    global params

    if params:
        return params

    try:
        response = client.get_parameters(
        Names=[
            'SMTP_PASSWORD',
            'SMTP_USER'
        ],
        WithDecryption=True)
    except ClientError as e:
        raise e

    params = {
        x["Name"]: x["Value"]
        for x in response["Parameters"]
    }
    return params

def send_email(to_email, destination, body):
    smtp_creds = get_email_secrets()
    msg = EmailMessage()
    msg["From"] = smtp_creds["SMTP_USER"]
    msg["To"] = to_email
    msg["Subject"] = f"Flight to {destination} Found!!!"
    msg.set_content(body)
    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(smtp_creds["SMTP_USER"], smtp_creds["SMTP_PASSWORD"])
        server.send_message(msg)

def delete_flight_alert(email, created_at):
    try:
        response = dynamodb.delete_item(
            Key={
                'email': email,
                'created': created
            }
        )
        return response
    except ClientError as e:
        print(f"Error deleting item: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Failed to delete item"})
        }

def update_item(email, created_at, status):
    try:
        table.update_item(
            Key={
                "email": email,
                "created_at": created_at
            },
            UpdateExpression="SET #s = :s",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":s": status}
        )
    except ClientError as e:
        print(e.response["Error"]["Message"])
    else:
        print("Item status successfully updated!")